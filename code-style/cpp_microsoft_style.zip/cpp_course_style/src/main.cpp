#include "student_report.h"

#include <exception>
#include <iostream>
#include <memory>

int main()
{
    try
    {
        auto report = std::make_unique<courseStyle::StudentReport>(
            courseStyle::StudentReport::GradeList{4, 5, 3});
        const courseStyle::Report& reportView = *report;
        reportView.Print(std::cout);
    }
    catch (const std::exception& error)
    {
        std::cerr << error.what() << '\n';
        return 1;
    }

    return 0;
}
