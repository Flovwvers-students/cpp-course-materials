#include "report.h"

#include <ostream>

namespace courseStyle
{
void Report::Print(std::ostream& stream) const
{
    if (GetRowCount() == 0)
    {
        stream << "No grades\n";
        return;
    }

    PrintBody(stream);
}
}
