#include "student_report.h"

#include <ostream>
#include <stdexcept>
#include <utility>

namespace courseStyle
{
StudentReport::StudentReport(GradeList grades) : m_grades(std::move(grades))
{
    ValidateGrades(m_grades);
}

const StudentReport::GradeList& StudentReport::GetGrades() const noexcept
{
    return m_grades;
}

double StudentReport::GetAverage() const
{
    if (m_grades.empty())
    {
        throw std::domain_error("Average requires at least one grade");
    }

    double totalGrade = 0.0;
    for (int grade : m_grades)
    {
        totalGrade += grade;
    }

    return totalGrade / static_cast<double>(m_grades.size());
}

std::size_t StudentReport::GetRowCount() const noexcept
{
    return m_grades.size();
}

void StudentReport::PrintBody(std::ostream& stream) const
{
    stream << "Average: " << GetAverage() << '\n';
}

void StudentReport::ValidateGrades(const GradeList& grades)
{
    for (int grade : grades)
    {
        if (grade < c_minGrade || grade > c_maxGrade)
        {
            throw std::invalid_argument("Grade must be between 2 and 5");
        }
    }
}
}
