#pragma once

#include "report.h"

#include <cstddef>
#include <iosfwd>
#include <vector>

namespace courseStyle
{
class StudentReport final : public Report
{
public:
    using GradeList = std::vector<int>;

    static constexpr int c_minGrade = 2;
    static constexpr int c_maxGrade = 5;

    explicit StudentReport(GradeList grades);

    ~StudentReport() override = default;

    [[nodiscard]] const GradeList& GetGrades() const noexcept;
    [[nodiscard]] double GetAverage() const;

    [[nodiscard]] std::size_t GetRowCount() const noexcept override;

protected:
    void PrintBody(std::ostream& stream) const override;

private:
    static void ValidateGrades(const GradeList& grades);

    GradeList m_grades;
};
}
