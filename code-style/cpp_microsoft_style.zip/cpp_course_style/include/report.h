#pragma once

#include <cstddef>
#include <iosfwd>

namespace courseStyle
{
class Report
{
public:
    Report(const Report&) = delete;
    Report(Report&&) = delete;

    virtual ~Report() = default;

    Report& operator=(const Report&) = delete;
    Report& operator=(Report&&) = delete;

    void Print(std::ostream& stream) const;

    [[nodiscard]] virtual std::size_t GetRowCount() const noexcept = 0;

protected:
    Report() = default;

    virtual void PrintBody(std::ostream& stream) const = 0;
};
}
